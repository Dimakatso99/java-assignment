public class Robots {

public static void main(String[ ] args) {

String[ ] names = new String[10];

System.out.println("Enter 10 names - ");
System.out.println("Enter the starting time ");


for (int i = 0; i < names.length; i++){

names[i] = new Scanner(System.in).nextLine( );

      int min = 1;
      int max = 4;
        
      //Generate random int value from 1 to 4
      System.out.println("Random value in int from "+min+" to "+max+ ":");
      int random_int = (int)Math.floor(Math.random()*(max-min+1)+min);
      System.out.println(random_int);
	
	  
	  
	  

}

}

}
