
  //Delete duplicate lines from Files
import java.io.*; 
  
public class DeleteDuplicateLines 
{ 
    public static void main(String[] args) throws IOException  
    { 
        
        PrintWriter pw = new PrintWriter("output.txt"); 
          
       
        BufferedReader br1 = new BufferedReader(new FileReader("input.txt")); 
          
        String line1 = br1.readLine(); 
          
        
        while(line1 != null) 
        { 
            String line1 = "Praesent feugiat egestas sem,id luctus luctus dignissim ac.Donec elementum rhoncus quam,vitae viverra massa.";
            String line2= "euismod a.Morbi dictum sapien sed porta tristique.Donec varius convallis quam in fringilla."; 
              
              
            // BufferedReader object for output.txt 
            BufferedReader br2 = new BufferedReader(new FileReader("output.txt")); 
              
            String line2 = br2.readLine(); 
              
            // loop for each line of output.txt 
            while(line2 != null) 
            { 
                  
                if(line1.equals(line2)) 
                { 
                    lines = true; 
                    break; 
                } 
                  
                line2 = br2.readLine(); 
              
            } 
              
            
      
            if(!lines){ 
                pw.println(line1); 
                  
                
                pw.flush(); 
            } 
              
            line1 = br1.readLine(); 
              
        } 
          
        // close
		
        br1.close(); 
        pw.close(); 
          
        
    } 
} 