package writemultipleLines;
 
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
 

public class WriteMultipleLines {
 
    
    public static void main(String[] args) {
       
        writeMultipleLines();
 
    }
 
    public static void writeMultipleLines() {
 
        // FileWriter declaration
		
        FileWriter fileWriter = null;
		
        //Stroying file name in a string.
		
        String pathname = "file1-1.txt";
		
        //Declaring String Array to hold multiple data
		
		 String[] lines = new String[7];
		 
		lines[0]"Praesent feugiatas sem,id luctus luctus dignissim ac.Donec elementum rhoncus quam,vitae viverra massa.");
		lines[1]("euismod a.Morbi dictum sapien sed porta tristique.Donec varius convallis quam in fringilla.");
		lines[2]("Lorem ipsum dolor sit amet,consectetur adipiscing elit.Suspendisse id enim euismod erat elementum cursus.");
		lines[3]("Praesent feugiat egestas sem,id luctus luctus dignissim ac.Donec elementum rhoncus quam,vitae viverra massa.");
		lines[4]("euismod a.Morbi dictum sapien sed porta tristique.Donec varius convallis quam in fringilla.");
		lines[5]("In hac habitasse platea dictumst.Etiam vitae tortor ipsum.Morbi massa augue,lacinia sed nisi id,congue eleifend lorem.");
		lines[6]("In pretium dictum lacinia.In nutrum,neque a didnissim maximus,dolor mi pretium ante,nec volutpat justo dolor non nulla.")
 
       
        try {
            //Creating File Object
			
            File file = new File(pathname);
            
            fileWriter = new FileWriter(file);
 
            int linecounter = 0;
 
            System.out.println("Writing content to a file.");
            for (int i = 0; i &amp;amp;lt; lines.length; i++) {
                //Writing content to a file
				
                fileWriter.write(lines[i] + "\n");
                
                linecounter++;
            }
 
            System.out.println("Finished Writing " + linecounter + " Lines to a file.");
        } catch (IOException iOException) {
            //Catching Exceptions.
			
            System.out.println("Error : " + iOException.getMessage());
        } finally {
 
            if (fileWriter != null) {
                try {
                    System.out.println("Closing file writer object");
                    
                    fileWriter.close();
                } catch (IOException iOException) {
                    System.out.println("Error : " + iOException.getMessage());
                }
            }
 
        }
 
    }
 
}
