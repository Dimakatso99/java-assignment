
// Java program to find area
// and perimeter of rectangle
import java.io.*;
 
class Rectangle {
	
	    Scanner in = new Scanner(System.in);
        System.out.print("Enter length of Rectangle: ");
        double a = in.nextDouble();
        System.out.print("Enter breadth of rectangle: ");
        double b = in.nextDouble();
        
 
    // Utility function
    static int areaRectangle(int a, int b)
    {
       int area = a * b;
       return area;
    }
 
    static int perimeterRectangle(int a, int b)
    {
       int perimeter = 2*(a + b);
       return perimeter;
    }
     
    // Driver Function
    public static void main (String[] args) {
 
       
       
        System.out.println("Area = "+ areaRectangle(a, b));
        System.out.println("Perimeter = "+ perimeterRectangle(a, b));
 
    }
}