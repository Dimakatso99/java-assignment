
import java.io.*;

public class PhoneBook {

//Store the data in a pair of arrays. 
//The phone number associated with the name names[i] is numbers[i].


private String[] names = new String[1];
private String[] numbers = new String[1];
private int count = 0;

//determines change

public boolean changed;  

// Removes any entries currently in the directory, and loads
// a new set of directory entries from the TextReader
// and throws exceptions

public void load(TextReader in) throws IOException {

int newCount = in.getlnInt();
String[] newNames = new String[newCount + 5];
String[] newNumbers = new String[newCount + 5];
for (int i = 0; i < newCount; i++) {
newNames[i] = in.getln();
newNumbers[i] = in.getln();
}
count = newCount;
names = newNames;
numbers = newNumbers;
changed = false;
}


public void save(PrintWriter out) {

// Saves all the entries in the directory to the PrintWriter.

out.println(count);
for (int i = 0; i < count; i++) {
out.println(names[i]);
out.println(numbers[i]);
}
}


public String numberFor(String name) {
// Get the phone number associated with the given name, if any.
// If the name does not exist in the directory, null is returned.

if (name == null)
throw new IllegalArgumentException("Name cannot be null in numberFor(name)");
int position = indexOf(name);
if (position == -1)
return null;
else
return numbers[position];
}

//Create a new entry in the directory for the given name and number.

public void addNewEntry(String name, String number) {

if (name == null)
throw new IllegalArgumentException("Name cannot be null in addNewEntry(name,number)");
if (number == null)
throw new IllegalArgumentException("Number cannot be null in addNewEntry(name,number)");
int position = indexOf(name);


if (count == names.length) {
String[] tempNames = new String[ 2*count ];
String[] tempNumbers = new String[ 2* count];
System.arraycopy(names, 0, tempNames, 0, count);
System.arraycopy(numbers, 0, tempNumbers, 0, count);
names = tempNames;
numbers = tempNumbers;
}
names[count] = name;
numbers[count] = number;
count++;
changed = true;
}


public void deleteEntry(String name) {
// Remove the entry for the specified name from the directory, if

if (name == null)
return;
int position = indexOf(name);
if (position == -1)
return;
names[position] = names[count-1];
numbers[position] = numbers[count-1];
count--;
changed = true;
}


// Change the number associated with the given name. An IllegalArgumentException
// is thrown if the name does not exist in the directory or if either of
// the parameters is null.

public void updateEntry(String name, String number) {


if (name == null)
throw new IllegalArgumentException("Name cannot be null in updateEntry(name,number)");
if (number == null)
throw new IllegalArgumentException("Number cannot be null in updateEntry(name,number)");
int position = indexOf(name);
if (position == -1)
throw new IllegalArgumentException("Name not found in updateEntry(name,number).");
numbers[position] = number;
changed = true;
}

// returns the position of the name in the names array,

private int indexOf(String name) {


for (int i = 0 ; i < count; i++) {
if (names[i].equalsIgnoreCase(name))
return i;
}
return -1;
}


} 
