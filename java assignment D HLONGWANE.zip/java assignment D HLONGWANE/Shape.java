

package za.ac.dnj.shape;
public abstract class Shape
{
protected String nameOfshape;
private int shapeID;
public Shape() {
}
public Shape(String nameOfshape, int shapeID) {
this.nameOfshape = nameOfshape; 
this.shapeID = shapeID;
}
public String getNameOfshape() {
return nameOfshape;

}
public void setNameOfshape(String nameOfshape) {
this.nameOfshape = nameOfshape;
}
public int getShapeID() {
return shapeID;
}
public void setShapeID(int shapeID) {
this.shapeID = shapeID;
}
public abstract double area();
public abstract double perimeter();
public boolean equals(Shape shape) 
{
boolean validate = false;
if (shape.getShapeID() == shapeID ) 
{
validate = true; 
}
return validate;
}
@Override
public String toString()
{
return nameOfshape + "#" + shapeID; 
}