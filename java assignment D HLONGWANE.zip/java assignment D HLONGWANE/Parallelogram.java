

package za.ac.dnj.parallelogram;
import za.ac.dnj.shape.Shape;


public class Parallelogram extends Shape
{
private int side;
private int base;
public Parallelogram() {
}


        
        
       


public Parallelogram( String nameOfshape, int shapeID,int side, int base) {
super(nameOfshape, shapeID); 
this.side = side;
this.base = base;
}

        Scanner s = new Scanner(System.in);
        System.out.print("Enter side:");
        side = s.nextInt();
        System.out.print("Enter base:");
        base= s.nextInt();


@Override
public double area()
{
return base * side ; or base * height; 


@Override
public double perimeter()
{
return 2 * (base + side); 
}

@Override
public String toString()
{
return super.toString() + "#"+base+ "#"+side; 

}
}