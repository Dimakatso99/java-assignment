

package za.ac.dnj.circle;
import za.ac.dnj.shape.Shape;
public class Circle extends Shape 
{
protected double radius;
public Circle() {
}
public Circle( String nameOfshape, int shapeID,double radius) {
super(nameOfshape, shapeID);
this.radius = radius; 

}


@Override
public double area()
{
return Math.PI * radius * radius; or Math.PI * Math.pow(radius, 2) ;
}
@Override
public double perimeter()
{
return 2 * Math.PI * radius;
}
public double diameter()
{
return 2 * radius; 
}
@Override
public String toString()
{
return super.toString() + "#"+radius; 
}