



import java.util.Scanner;
 
public class Square {
 
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.printf("1. Enter side of square : ");
            double side = scanner.nextDouble();         
                 
            //Area of square is side * side
            double area = side * side;
            //Print area up to two precision
            System.out.printf("2. Area of square is : %4.2f",area);
             
            //Area of square is side * side
            double Perimeter = 4 * side;
            //Print area up to two precision
            System.out.printf("\n3. Perimeter of square is : %4.2f",Perimeter);
        }
    }
}