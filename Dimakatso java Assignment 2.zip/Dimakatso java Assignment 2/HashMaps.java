public class HashMaps{
	
	 public static void main(String[] args)
    {
HashMap<String,Integer>hashmap_original=new HashMap<>();
       //insert keys
	    hashmap.put("key_1",9);
        hashmap.put("key_2",8);
        hashmap.put("key_3",4);
        hashmap.put("key_4",1);
        hashmap.put("key_5",3);
		hashmap.put("key_6",23);
		hashmap.put("key_7",65);

        HashMap<String,Integer>hashmap_result=new HashMap<>();
        int int_minium_value = 99999; //max value for program
        for (String String_key:hashmap_original.keySet()) {
            int int_compare_value=hashmap_original.get(String_key); //get the value

            if (int_compare_value<int_minium_value) {
                int_minium_value=int_compare_value;//compare values
                hashmap_result.clear(); //delete non min values
                hashmap_result.put(String_key,int_compare_value);
            } else if (int_compare_value==int_minium_value) {
                hashmap_result.put(String_key,int_compare_value);
            }

        }
		//get results
        String result=null;
        for (String key_with_the_lowest_value : hashmap_result.keySet()) {
            if (result == null) {
                result = key_with_the_lowest_value;
            } else {
                result=result+","+key_with_the_lowest_value;
		    }
        }

	}
}
}