import java.util.LinkedList;
import java.util.*;

public class Collections{

    public static void main(String[] args)
    {
LinkedList<Integer> Firstcollection = new LinkedList<>();
        Firstcollection.add(1);
        Firstcollection.add(2);
        Firstcollection.add(3);
		Firstcollection.add(4);
		Firstcollection.add(5);
		
		Scanner sc= new Scanner (System.in );
        LinkedList<Integer>list=new 
        LinkedList<>();
        System.out.println("Enter the value of the element"); 
        
       int value = sc.nextInt();
        
		
LinkedList<Integer> Secondcollection = new LinkedList<>();
        Secondcollection.add(6);
        Secondcollection.add(7);
        Secondcollection.add(8);
		Secondcollection.add(9);
LinkedList<Integer> results = new LinkedList<>();
        results.addAll(Firstcollection);
         results.addAll(Secondcollection);
		 
		 

System.out.println("First collection : "+Firstcollection);
System.out.println("Second collection : "+Secondcollection);
System.out.println ("Element value (not its number!):"+value);
System.out.println("Results : "+results);
}
}