import java.util.ArrayList;

class ArrayLst {
  public static void main(String[] args) {
    ArrayList<String> numbers = new ArrayList<>();

    // add elements in the array list
	numbers.add("one");
    numbers.add("two");
    numbers.add("three");
    numbers.add("four");
	
    System.out.println("ArrayList: " + numbers);

    // remove element from index 2
    
	String str = numbers.remove(2);
	numbers.add("eight");
	
    System.out.println("Updated ArrayList: " + numbers);
    System.out.println("Removed Element: " + str);
  }
}